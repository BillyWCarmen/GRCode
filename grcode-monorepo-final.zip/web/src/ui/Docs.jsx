
import React from 'react'
export default function Docs(){
  return <div className="max-w-3xl mx-auto px-6 py-12">
    <h1 className="text-3xl font-extrabold">GRCode.ai — Nature Is the Code</h1>
    <p className="mt-4 text-slate-700">Use natural micro‑texture as unclonable identity. Phone‑only mint & verify.</p>
    <h2 className="mt-8 text-xl font-bold">How it works</h2>
    <ol className="list-decimal ml-6 text-slate-700">
      <li>Detect — YOLO segmentation finds a stable patch</li>
      <li>Fingerprint — 128‑D embedding</li>
      <li>Verify — vector search vs threshold τ</li>
      <li>Liveness — micro‑parallax & quality checks</li>
    </ol>
  </div>
}

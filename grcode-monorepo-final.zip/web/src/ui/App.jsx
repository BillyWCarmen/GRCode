
import React, { useMemo, useState } from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import Docs from './Docs.jsx'

function ContactForm(){
  const [form,setForm]=React.useState({name:'',email:'',company:'',message:''})
  const [status,setStatus]=React.useState(null)
  async function submit(e){
    e.preventDefault(); setStatus('sending')
    try{
      const res = await fetch('/.netlify/functions/contact',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(form)})
      const data = await res.json(); setStatus(data.ok?'sent':'error')
    }catch{ setStatus('error') }
  }
  return <form onSubmit={submit} className="grid md:grid-cols-2 gap-4 mt-4">
    <input className="border rounded-xl px-4 py-3" placeholder="Your name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
    <input required className="border rounded-xl px-4 py-3" type="email" placeholder="Your email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/>
    <input className="md:col-span-2 border rounded-xl px-4 py-3" placeholder="Company / Use case" value={form.company} onChange={e=>setForm({...form,company:e.target.value})}/>
    <textarea required className="md:col-span-2 border rounded-xl px-4 py-3" rows="4" placeholder="How can we help?" value={form.message} onChange={e=>setForm({...form,message:e.target.value})}/>
    <button className="md:col-span-2 px-5 py-3 rounded-xl bg-slate-900 text-white" disabled={status==='sending'}>{status==='sending'?'Sending…':'Get in touch'}</button>
    {status==='sent' && <div className="md:col-span-2 text-green-700">Thanks — we’ll be in touch.</div>}
    {status==='error' && <div className="md:col-span-2 text-red-600">Something went wrong.</div>}
  </form>
}

function Home(){
  const [t,setT]=useState(0.92)
  const data=useMemo(()=>{
    const n=120, xs=[...Array(n)].map((_,i)=>0.5+i*(0.99-0.5)/(n-1))
    const FAR=xs.map(x=>0.5*(1-Math.tanh((t-x)/0.02)))
    const FRR=xs.map(x=>0.5*(1+Math.tanh((t-x)/0.02)))
    return xs.map((x,i)=>({x:x.toFixed(3),FAR:FAR[i],FRR:FRR[i]}))
  },[t])
  return <main>
    <section className="max-w-6xl mx-auto px-6 py-16">
      <div className="grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h1 className="text-4xl md:text-5xl font-extrabold leading-tight">Nature Is the Code</h1>
          <p className="mt-4 text-lg text-slate-700">Mint & verify real-world identity from natural texture. No labels or chips.</p>
          <div className="mt-6 flex gap-3">
            <a href="#sim" className="px-5 py-3 rounded-xl bg-slate-900 text-white">Try simulator</a>
            <Link to="/docs" className="px-5 py-3 rounded-xl border border-slate-300">Docs</Link>
          </div>
        </div>
        <div className="rounded-3xl overflow-hidden shadow-xl border border-slate-200"><div className="aspect-video grid place-items-center text-slate-500">Demo placeholder</div></div>
      </div>
    </section>
    <section id="sim" className="max-w-6xl mx-auto px-6 py-16">
      <h2 className="text-2xl font-bold">Verification Threshold Simulator</h2>
      <div className="grid md:grid-cols-3 gap-6 mt-6">
        <div className="md:col-span-2 p-5 border rounded-2xl bg-white h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <XAxis dataKey="x"/><YAxis domain={[0,1]}/><Tooltip/><Legend/>
              <Line type="monotone" dataKey="FAR" dot={false} strokeWidth={2}/>
              <Line type="monotone" dataKey="FRR" dot={false} strokeWidth={2}/>
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="p-5 border rounded-2xl bg-white">
          <label className="block text-sm text-slate-600">Threshold τ</label>
          <input type="range" min="0.5" max="0.99" step="0.001" value={t} onChange={e=>setT(parseFloat(e.target.value))} className="w-full"/>
          <div className="mt-2 font-mono">τ = {t.toFixed(3)}</div>
        </div>
      </div>
    </section>
    <section id="contact" className="max-w-3xl mx-auto px-6 py-16">
      <div className="p-6 rounded-2xl border bg-white">
        <h2 className="text-xl font-bold">Pilot with GRCode.ai</h2>
        <p className="text-sm text-slate-700 mt-2">Design partners wanted in timber, agri, and brand protection.</p>
        <ContactForm/>
      </div>
    </section>
  </main>
}

export default function App(){
  return <div>
    <header className="max-w-6xl mx-auto px-6 py-8 flex items-center justify-between">
      <div className="flex items-center space-x-3"><div className="w-9 h-9 rounded-xl bg-slate-900 text-white grid place-items-center font-bold">GR</div><span className="font-semibold">GRCode.ai</span></div>
      <nav className="hidden md:flex items-center space-x-8 text-sm">
        <a href="#sim" className="hover:text-slate-600">Simulator</a>
        <Link to="/docs" className="hover:text-slate-600">Docs</Link>
        <a href="#contact" className="px-4 py-2 rounded-xl bg-slate-900 text-white hover:opacity-90">Talk to us</a>
      </nav>
    </header>
    <Routes>
      <Route path="/" element={<Home/>}/>
      <Route path="/docs" element={<Docs/>}/>
    </Routes>
    <footer className="max-w-6xl mx-auto px-6 py-10 text-sm text-slate-500">© GRCode.ai — All rights reserved.</footer>
  </div>
}

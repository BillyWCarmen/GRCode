
const nodemailer = require('nodemailer')
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' }
  try {
    const { name, email, company, message } = JSON.parse(event.body || '{}')
    if (!email || !message) return { statusCode: 400, body: 'Missing required fields.' }
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST, port: parseInt(process.env.SMTP_PORT || '587',10), secure: false,
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    })
    const from = process.env.FROM_EMAIL || process.env.SMTP_USER
    const to = process.env.TO_EMAIL
    await transporter.sendMail({ from, to, subject: `GRCode.ai contact — ${name||'No name'}`, text: `From: ${name||''} <${email}>
Company: ${company||''}

${message}` })
    return { statusCode: 200, body: JSON.stringify({ ok: true }) }
  } catch (e) { return { statusCode: 500, body: JSON.stringify({ ok:false, error:String(e) }) } }
}


import os, json, requests, pandas as pd, numpy as np, streamlit as st, matplotlib.pyplot as plt

st.set_page_config(page_title="GRCode Admin", layout="wide")
st.title("GRCode Admin Dashboard")
with st.sidebar:
    base_url = st.text_input("Server URL", os.environ.get("GRCODE_SERVER_URL","http://localhost:8000"))
    if st.button("Ping"):
        try: st.success(requests.get(f"{base_url}/health").json())
        except Exception as e: st.error(e)

tabs = st.tabs(["Config","Registry","Logs","Quick ROC","Metrics","Labeler"])

with tabs[0]:
    st.subheader("Config")
    try: cfg = requests.get(f"{base_url}/config").json().get("config",{})
    except Exception as e: st.error(e); cfg={}
    a = st.number_input("accept_dot", 0.5, 0.999, float(cfg.get("accept_dot",0.92)), 0.001, format="%.3f")
    f = st.number_input("min_focus", 0.0, 500.0, float(cfg.get("min_focus",50.0)))
    e = st.number_input("min_entropy", 0.0, 10.0, float(cfg.get("min_entropy",3.5)), 0.1)
    if st.button("Save"):
        st.write(requests.post(f"{base_url}/config", json={"accept_dot":a,"min_focus":f,"min_entropy":e}).json())

with tabs[1]:
    st.subheader("Registry")
    if st.button("Refresh"):
        st.session_state["reg"]=requests.get(f"{base_url}/registry").json()
    d=st.session_state.get("reg"); 
    if d: st.dataframe(pd.DataFrame(d.get("items",[])), use_container_width=True, height=350)
    del_id = st.text_input("Delete id"); 
    c1,c2,c3 = st.columns(3)
    if c1.button("Delete"): st.write(requests.delete(f"{base_url}/registry/{del_id}").json())
    if c2.button("Snapshot"): st.write(requests.post(f"{base_url}/registry/snapshot").json())
    snap = st.text_input("Snapshot name to restore")
    if c3.button("Restore"): st.write(requests.post(f"{base_url}/registry/restore", json={"snapshot":snap}).json())
    st.markdown("---")
    cA,cB = st.columns(2)
    if cA.button("Export .npz"): st.info("Open /registry/export in your browser to download.")
    up = cB.file_uploader("Import .npz", type=["npz"])
    if up and st.button("Import (replace)"):
        st.write(requests.post(f"{base_url}/registry/import", files={"file":up.getvalue()}, data={"mode":"replace"}).json())

with tabs[2]:
    st.subheader("Logs")
    p=os.path.join("registry","log.csv")
    if os.path.exists(p):
        df=pd.read_csv(p); st.write(f"{len(df)} rows"); st.dataframe(df.tail(300), use_container_width=True, height=350)
        if "ok" in df.columns:
            df["t"]=pd.to_datetime(df["ts"], unit="s"); df=df.sort_values("t"); df["roll"]=df["ok"].rolling(50,min_periods=5).mean()
            fig,ax=plt.subplots(); ax.plot(df["t"],df["roll"]); ax.set_ylim(0,1); ax.grid(True); st.pyplot(fig)
    else: st.info("No log yet.")

with tabs[3]:
    st.subheader("Quick ROC")
    up=st.file_uploader("CSV with score,label", type=["csv"])
    if up:
        from sklearn.metrics import roc_curve, auc
        df=pd.read_csv(up); fpr,tpr,thr=roc_curve(df["label"], df["score"]); A=auc(fpr,tpr)
        st.write(f"AUC={A:.3f}")
        fig,ax=plt.subplots(); ax.plot(fpr,tpr); ax.grid(True); st.pyplot(fig)
        import numpy as np
        target=st.slider("Target FAR",0.0,0.2,0.01,0.001); i=int(np.argmin(np.abs(fpr-target))); tau=float(thr[i]); st.success(f"τ≈{tau:.3f}")

with tabs[4]:
    st.subheader("Metrics (FAR/FRR vs τ)")
    src=st.radio("Source",["CSV upload","Server log (labeled)"])
    def plot_metrics(df):
        import numpy as np
        taus=np.linspace(0.5,0.99,100); fars=[]; frrs=[]; y=df["label"].astype(int).to_numpy(); s=df["score"].astype(float).to_numpy()
        for t in taus:
            p=(s>=t).astype(int); fp=((p==1)&(y==0)).sum(); tn=((p==0)&(y==0)).sum(); fn=((p==0)&(y==1)).sum(); tp=((p==1)&(y==1)).sum()
            fars.append(fp/max(1,(fp+tn))); frrs.append(fn/max(1,(fn+tp)))
        import numpy as np
        i=int(np.argmin(np.abs(np.array(fars)-np.array(frrs)))); eer=(fars[i]+frrs[i])/2; st.write(f"EER≈{eer:.3f} at τ≈{taus[i]:.3f}")
        fig,ax=plt.subplots(); ax.plot(taus,fars,label="FAR"); ax.plot(taus,frrs,label="FRR"); ax.legend(); ax.grid(True); ax.set_ylim(0,1); st.pyplot(fig)
    if src=="CSV upload":
        up=st.file_uploader("CSV score,label", type=["csv"])
        if up: plot_metrics(pd.read_csv(up))
    else:
        p=os.path.join("registry","log.csv")
        if os.path.exists(p):
            df=pd.read_csv(p)
            if set(["score","label"]).issubset(df.columns): plot_metrics(df.dropna(subset=["score","label"]))
            else: st.warning("No 'label' column in log.")
        else: st.info("No log yet.")

with tabs[5]:
    st.subheader("Labeler")
    p=os.path.join("registry","log.csv")
    if os.path.exists(p):
        df=pd.read_csv(p); 
        if "label" not in df.columns: df["label"]=np.nan
        edited=st.data_editor(df, use_container_width=True, height=400, num_rows="dynamic")
        if st.button("Save log.csv"):
            edited.to_csv(p, index=False); st.success("Saved")
    else: st.info("No log yet.")

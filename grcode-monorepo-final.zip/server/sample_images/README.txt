Put a few JPG/PNG images here for mint/verify demos.

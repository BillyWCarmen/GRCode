
#!/usr/bin/env python3
"""GRCode demo client

Mint or verify an image against the running FastAPI server.

Examples:
  python demo_client.py --server http://localhost:8000 mint --image ./sample_images/board_001.jpg --id board_001.jpg
  python demo_client.py --server http://localhost:8000 verify --image ./sample_images/board_001_newshot.jpg
"""
import argparse, base64, requests, sys
from pathlib import Path

def encode_b64(path: Path) -> str:
    data = path.read_bytes()
    return base64.b64encode(data).decode('ascii')

def do_mint(server, image, image_id=None):
    img_b64 = encode_b64(Path(image))
    payload = {"image_b64": img_b64}
    if image_id: payload["image_id"] = image_id
    r = requests.post(f"{server}/mint", json=payload, timeout=30)
    print(r.status_code, r.json())

def do_verify(server, image):
    img_b64 = encode_b64(Path(image))
    r = requests.post(f"{server}/verify", json={"image_b64": img_b64}, timeout=30)
    print(r.status_code, r.json())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--server", default="http://localhost:8000")
    sub = ap.add_subparsers(dest="cmd", required=True)

    ap_m = sub.add_parser("mint");    ap_m.add_argument("--image", required=True); ap_m.add_argument("--id")
    ap_v = sub.add_parser("verify");  ap_v.add_argument("--image", required=True)

    a = ap.parse_args()
    if a.cmd == "mint": do_mint(a.server, a.image, a.id)
    elif a.cmd == "verify": do_verify(a.server, a.image)
    else: sys.exit(2)

if __name__ == "__main__":
    main()


import numpy as np, cv2
from ultralytics import YOLO

class Segmenter:
    def __init__(self, weights_path: str):
        self.model = YOLO(weights_path) if weights_path else YOLO('yolov8n-seg.pt')

    def infer(self, bgr):
        h,w = bgr.shape[:2]
        res = self.model.predict(bgr, imgsz=640, conf=0.25, verbose=False)
        if not res or res[0].masks is None or len(res[0].masks)==0:
            return None, None
        r = res[0]
        conf = r.boxes.conf.cpu().numpy()
        idx = int(conf.argmax())
        mask = r.masks.data[idx].cpu().numpy().astype(np.uint8)*255
        mask = cv2.resize(mask, (w,h), interpolation=cv2.INTER_NEAREST)
        return mask, r.boxes.xyxy[idx].cpu().numpy().tolist()

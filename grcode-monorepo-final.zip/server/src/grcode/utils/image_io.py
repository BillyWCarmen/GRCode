
import base64, io, cv2, numpy as np
from PIL import Image
from skimage.metrics import structural_similarity as ssim

def decode_b64_to_bgr(image_b64: str):
    data = base64.b64decode(image_b64)
    img = Image.open(io.BytesIO(data)).convert("RGB")
    return cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)

def to_gray(bgr): return cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)

def crop_by_mask(bgr, mask):
    ys, xs = (mask>0).nonzero()
    if len(xs)==0: return None
    x0,x1,y0,y1 = xs.min(), xs.max(), ys.min(), ys.max()
    x0=max(0,x0-2); y0=max(0,y0-2); x1=min(bgr.shape[1]-1,x1+2); y1=min(bgr.shape[0]-1,y1+2)
    return bgr[y0:y1+1, x0:x1+1]

def laplacian_var(gray): return float(cv2.Laplacian(gray, cv2.CV_64F).var())

def entropy(gray):
    hist = cv2.calcHist([gray],[0],None,[256],[0,256]).ravel()
    p = hist / (hist.sum()+1e-8); p = p[p>0]
    return float(-(p*np.log2(p)).sum())

def mask_iou(a,b):
    a=(a>0).astype(np.uint8); b=(b>0).astype(np.uint8)
    inter=(a&b).sum(); union=(a|b).sum()+1e-6
    return float(inter/union)

def ssim_gray(g1,g2):
    g1=(g1/255.0).astype('float32'); g2=(g2/255.0).astype('float32')
    s,_=ssim(g1,g2,full=True)
    return float(s)

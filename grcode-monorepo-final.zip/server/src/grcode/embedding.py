
import numpy as np, cv2

def lbp_embed(gray):
    h,w = gray.shape; lbp = np.zeros_like(gray, dtype=np.uint8)
    for i in range(1, h-1):
        for j in range(1, w-1):
            c=gray[i,j]; code=0
            code |= (gray[i-1,j-1]>=c)<<7; code |= (gray[i-1,j]>=c)<<6; code |= (gray[i-1,j+1]>=c)<<5
            code |= (gray[i,j+1]>=c)<<4;  code |= (gray[i+1,j+1]>=c)<<3; code |= (gray[i+1,j]>=c)<<2
            code |= (gray[i+1,j-1]>=c)<<1; code |= (gray[i,j-1]>=c)<<0
            lbp[i,j]=code
    hist,_=np.histogram(lbp.ravel(), bins=256, range=(0,256), density=True)
    v=hist.astype('float32'); v/= (np.linalg.norm(v)+1e-8); return v


import os, time, json, threading, io, tempfile
import numpy as np, faiss
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
from src.grcode.segment import Segmenter
from src.grcode.embedding import lbp_embed
from src.grcode.utils.image_io import decode_b64_to_bgr, to_gray, crop_by_mask, mask_iou, ssim_gray

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

YOLO_WEIGHTS = os.environ.get("GRCODE_YOLO_WEIGHTS", "models/best.pt")
REGISTRY_DIR = os.environ.get("GRCODE_REGISTRY_DIR", "registry")
os.makedirs(REGISTRY_DIR, exist_ok=True)

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.json")
if not os.path.exists(CONFIG_PATH):
    json.dump({"accept_dot":0.92,"min_focus":50.0,"min_entropy":3.5}, open(CONFIG_PATH,"w"), indent=2)

def load_cfg(): return json.load(open(CONFIG_PATH))
def save_cfg(c): json.dump(c, open(CONFIG_PATH,"w"), indent=2)

_cfg = load_cfg()
ACCEPT_DOT = float(os.environ.get("GRCODE_ACCEPT_DOT", _cfg.get("accept_dot",0.92)))
MIN_FOCUS  = float(os.environ.get("GRCODE_MIN_FOCUS", _cfg.get("min_focus",50.0)))
MIN_ENTROPY= float(os.environ.get("GRCODE_MIN_ENTROPY", _cfg.get("min_entropy",3.5)))

INDEX_PATH = os.path.join(REGISTRY_DIR, "index.faiss")
IDS_PATH   = os.path.join(REGISTRY_DIR, "ids.json")
VECT_PATH  = os.path.join(REGISTRY_DIR, "vectors.npy")
LOG_PATH   = os.path.join(REGISTRY_DIR, "log.csv")
SNAPS_DIR  = os.path.join(REGISTRY_DIR, "snapshots"); os.makedirs(SNAPS_DIR, exist_ok=True)

def log_event(e: dict):
    hdr = "ts,route,ok,score,match_id,extra\n"
    line = f"{time.time()},{e.get('route','')},{int(e.get('ok',0))},{e.get('score','')},{e.get('match_id','')},{json.dumps(e.get('extra',{}))}\n"
    if not os.path.exists(LOG_PATH): open(LOG_PATH,"w").write(hdr+line)
    else: open(LOG_PATH,"a").write(line)

class Registry:
    def __init__(self):
        self.lock = threading.Lock()
        self.index=None; self.ids=[]; self.vectors=None
        self._load()

    def _rebuild(self):
        if self.vectors is None or len(self.ids)==0: self.index=None; return
        d=self.vectors.shape[1]; self.index=faiss.IndexFlatIP(d); self.index.add(self.vectors)

    def _load(self):
        if os.path.exists(VECT_PATH) and os.path.exists(IDS_PATH):
            self.vectors = np.load(VECT_PATH).astype(np.float32)
            self.ids = json.load(open(IDS_PATH))
            self._rebuild()

    def save(self):
        if self.index is not None: faiss.write_index(self.index, INDEX_PATH)
        json.dump(self.ids, open(IDS_PATH,"w"), indent=2)
        if self.vectors is not None: np.save(VECT_PATH, self.vectors)

    def add(self, v: np.ndarray, image_id: str):
        with self.lock:
            v=v.astype(np.float32).reshape(1,-1)
            self.vectors = v if self.vectors is None else np.vstack([self.vectors, v])
            self.ids.append(image_id)
            self._rebuild(); self.save()

    def search(self, q: np.ndarray, k=5):
        with self.lock:
            if self.index is None or len(self.ids)==0: return None, None
            D,I = self.index.search(q.reshape(1,-1).astype(np.float32), k)
            return D,I

    def remove(self, image_id: str):
        with self.lock:
            if image_id not in self.ids or self.vectors is None: return False
            idx=self.ids.index(image_id)
            mask=np.ones(len(self.ids), dtype=bool); mask[idx]=False
            self.ids=[i for j,i in enumerate(self.ids) if mask[j]]
            self.vectors=self.vectors[mask]
            self._rebuild(); self.save(); return True

    def snapshot(self):
        ts=int(time.time()); d=os.path.join(SNAPS_DIR, f"snap_{ts}"); os.makedirs(d, exist_ok=True)
        json.dump(self.ids, open(os.path.join(d,"ids.json"),"w"), indent=2)
        if self.vectors is not None: np.save(os.path.join(d,"vectors.npy"), self.vectors)
        return os.path.basename(d)

    def restore(self, snap):
        d=os.path.join(SNAPS_DIR, snap)
        try:
            self.ids=json.load(open(os.path.join(d,"ids.json")))
            self.vectors=np.load(os.path.join(d,"vectors.npy")).astype(np.float32)
            self._rebuild(); self.save(); return True
        except Exception as e:
            print("restore failed:", e); return False

reg = Registry()
seg = Segmenter(YOLO_WEIGHTS)

class MintReq(BaseModel):
    image_b64: str
    image_id: str | None = None

class VerifyReq(BaseModel):
    image_b64: str
    label: int | None = None

class Verify2Req(BaseModel):
    image_b64_a: str
    image_b64_b: str

@app.get("/health")
def health(): return {"ok": True, "size": len(reg.ids)}

@app.get("/config")
def get_config():
    return {"ok": True, "config": {"accept_dot":ACCEPT_DOT, "min_focus":MIN_FOCUS, "min_entropy":MIN_ENTROPY}}

class ConfigReq(BaseModel):
    accept_dot: float | None = None
    min_focus: float | None = None
    min_entropy: float | None = None

@app.post("/config")
def set_config(req: ConfigReq):
    global ACCEPT_DOT, MIN_FOCUS, MIN_ENTROPY
    new = {"accept_dot": float(req.accept_dot) if req.accept_dot is not None else ACCEPT_DOT,
           "min_focus": float(req.min_focus) if req.min_focus is not None else MIN_FOCUS,
           "min_entropy": float(req.min_entropy) if req.min_entropy is not None else MIN_ENTROPY}
    save_cfg(new); ACCEPT_DOT, MIN_FOCUS, MIN_ENTROPY = new["accept_dot"], new["min_focus"], new["min_entropy"]
    return {"ok": True, "config": new}

@app.post("/mint")
def mint(req: MintReq):
    bgr = decode_b64_to_bgr(req.image_b64)
    mask,_=seg.infer(bgr)
    if mask is None: return {"ok": False, "reason": "no mask"}
    crop=crop_by_mask(bgr,mask)
    if crop is None: return {"ok": False, "reason": "no crop"}
    gray=to_gray(crop); v=lbp_embed(gray)
    image_id = req.image_id or f"img_{int(time.time())}.jpg"
    reg.add(v, image_id)
    log_event({"route":"/mint","ok":True,"score":None,"match_id":image_id})
    return {"ok": True, "image_id": image_id, "registry_size": len(reg.ids)}

@app.post("/verify")
def verify(req: VerifyReq):
    bgr = decode_b64_to_bgr(req.image_b64)
    mask,_=seg.infer(bgr)
    if mask is None: return {"ok": False, "reason": "no mask"}
    crop=crop_by_mask(bgr,mask)
    if crop is None: return {"ok": False, "reason": "no crop"}
    gray=to_gray(crop); q=lbp_embed(gray)
    D,I = reg.search(q, 5)
    if D is None: return {"ok": False, "reason": "empty registry"}
    score=float(D[0,0]); match_id=reg.ids[int(I[0,0])]
    ok = bool(score >= ACCEPT_DOT)
    log_event({"route":"/verify","ok":ok,"score":score,"match_id":match_id,"extra":{"label": req.label}})
    return {"ok": ok, "score": score, "match_id": match_id, "topk": [(reg.ids[int(i)], float(D[0,j])) for j,i in enumerate(I[0])]}

@app.post("/verify2")
def verify2(req: Verify2Req):
    b1 = decode_b64_to_bgr(req.image_b64_a); b2 = decode_b64_to_bgr(req.image_b64_b)
    m1,_=seg.infer(b1); m2,_=seg.infer(b2)
    if m1 is None or m2 is None: return {"ok": False, "reason": "no mask(s)"}
    from src.grcode.utils.image_io import to_gray
    c1=crop_by_mask(b1,m1); c2=crop_by_mask(b2,m2)
    if c1 is None or c2 is None: return {"ok": False, "reason": "no crop(s)"}
    g1=to_gray(c1); g2=to_gray(c2)
    s1=lbp_embed(g1); s2=lbp_embed(g2)
    D1,I1=reg.search(s1,1); D2,I2=reg.search(s2,1)
    if D1 is None or D2 is None: return {"ok": False, "reason": "empty registry"}
    iou=mask_iou(m1,m2); sim=ssim_gray(g1,g2)
    ok = (float(D1[0,0])>=ACCEPT_DOT) and (float(D2[0,0])>=ACCEPT_DOT) and (iou>0.5) and (sim<0.98)
    match = reg.ids[int(I1[0,0])] if int(I1[0,0])==int(I2[0,0]) else [reg.ids[int(I1[0,0])], reg.ids[int(I2[0,0])]]
    resp={"ok": bool(ok), "scores":[float(D1[0,0]), float(D2[0,0])], "match_id": match, "mask_iou": float(iou), "ssim": float(sim)}
    log_event({"route":"/verify2","ok":resp["ok"],"score":resp["scores"][0],"match_id": (match if isinstance(match,str) else None), "extra":{"s2":resp["scores"][1],"iou":resp["mask_iou"],"ssim":resp["ssim"]}})
    return resp

@app.get("/registry")
def list_registry(limit: int=100, offset: int=0):
    end=min(len(reg.ids), offset+limit)
    items=[{"id":reg.ids[i]} for i in range(offset,end)]
    return {"ok": True, "total": len(reg.ids), "items": items}

@app.delete("/registry/{image_id}")
def delete_entry(image_id: str):
    return {"ok": bool(reg.remove(image_id))}

@app.post("/registry/snapshot")
def snapshot_registry():
    snap = reg.snapshot()
    return {"ok": True, "snapshot": snap}

@app.post("/registry/restore")
def restore_registry(data: dict):
    snap = data.get("snapshot")
    ok = reg.restore(snap)
    return {"ok": ok, "snapshot": snap}

@app.get("/registry/export")
def export_registry():
    out_path = os.path.join(REGISTRY_DIR, "registry_export.npz")
    np.savez(out_path, ids=np.array(reg.ids, dtype=object), vectors=reg.vectors)
    return FileResponse(out_path, filename="registry_export.npz")

@app.post("/registry/import")
def import_registry(file: UploadFile = File(...), mode: str = Form("replace")):
    tmp = tempfile.NamedTemporaryFile(delete=False)
    tmp.write(file.file.read()); tmp.close()
    try:
        data = np.load(tmp.name, allow_pickle=True)
        ids = data["ids"].tolist(); vectors = data["vectors"].astype(np.float32)
        if mode == "replace":
            reg.ids, reg.vectors = ids, vectors
        else:
            reg.ids.extend(ids)
            reg.vectors = vectors if reg.vectors is None else np.vstack([reg.vectors, vectors])
        reg._rebuild(); reg.save()
        return {"ok": True, "mode": mode, "count": len(reg.ids)}
    except Exception as e:
        return {"ok": False, "error": str(e)}
    finally:
        os.unlink(tmp.name)

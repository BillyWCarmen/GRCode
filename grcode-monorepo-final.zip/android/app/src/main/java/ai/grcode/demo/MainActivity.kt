
package ai.grcode.demo
import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import android.widget.FrameLayout

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    val view = PreviewView(this)
    setContentView(FrameLayout(this).apply { addView(view, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)) })
    val controller = LifecycleCameraController(this)
    view.controller = controller
    val launcher = registerForActivityResult(ActivityResultContracts.RequestPermission()){ granted -> if(granted) controller.bindToLifecycle(this) }
    if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) controller.bindToLifecycle(this)
    else launcher.launch(Manifest.permission.CAMERA)
  }
}


# GRCode Android Demo (Skeleton)

Open this folder in **Android Studio**. It will set up the Gradle wrapper automatically.
This skeleton includes a basic `MainActivity` and CameraX dependency placeholders.
Wire it to your FastAPI server at `http://10.0.2.2:8000` when running in the emulator.

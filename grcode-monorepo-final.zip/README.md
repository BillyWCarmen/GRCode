# GRCode.ai — Nature Is the Code 🌱🔐

[![Docker Build](https://github.com/YOUR_ORG/YOUR_REPO/actions/workflows/docker.yml/badge.svg)](../../actions/workflows/docker.yml)
[![Android Release](https://github.com/YOUR_ORG/YOUR_REPO/actions/workflows/android-release.yml/badge.svg)](../../actions/workflows/android-release.yml)
[![Web Pages](https://github.com/YOUR_ORG/YOUR_REPO/actions/workflows/pages.yml/badge.svg)](../../actions/workflows/pages.yml)
[![Netlify Deploy](https://github.com/YOUR_ORG/YOUR_REPO/actions/workflows/netlify.yml/badge.svg)](../../actions/workflows/netlify.yml)

> **GRCode.ai** uses **natural micro-texture** as an unclonable identity — mint & verify real-world items with a phone camera. No QR codes. No chips. Just nature.

---

## Monorepo Structure

```
/server   → FastAPI service (mint/verify, registry, admin UI)
/web      → React (Vite) landing site + docs + Netlify contact
/android  → Android demo skeleton (CameraX starter)
/.github  → CI for Docker → GHCR, Android Releases, GitHub Pages, Netlify
Makefile  → Common developer commands
```

---

## Quick Start

### Server (FastAPI + Streamlit Admin)
```bash
cd server
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
bash run_server.sh   # → http://localhost:8000

# Admin Dashboard
streamlit run admin_dashboard.py   # → http://localhost:8501
```

### Web (React + Vite)
```bash
cd web
npm install
npm run dev    # → http://localhost:5173
```

### Android
Open `android/` in **Android Studio**.  
Server is reachable at `http://10.0.2.2:8000` inside the emulator.

---

## API Reference

### Health
```
GET /health
```

### Mint
```
POST /mint
{ "image_b64": "<base64>", "image_id": "optional_id" }
```

### Verify
```
POST /verify
{ "image_b64": "<base64>" }
```

### Verify2 (pairwise)
```
POST /verify2
{ "image_b64_a": "<base64>", "image_b64_b": "<base64>" }
```

### Registry
- `GET /registry`
- `DELETE /registry/{id}`
- `POST /registry/snapshot`
- `POST /registry/restore`
- `GET /registry/export`
- `POST /registry/import`

### Config
- `GET /config`
- `POST /config` with `{ accept_dot, min_focus, min_entropy }`

---

## Pilot Checklist ✅

1. **Collect Data**
   - 50–100 samples per object, various lighting/angles.
   - Use `/mint` to build registry.

2. **Verify Performance**
   - Use `/verify` (and `/verify2` for pairwise checks).
   - Export registry for backups.

3. **Tune Thresholds (τ)**
   - Set `accept_dot` in `/config` or via Admin UI.
   - Use Quick ROC / Metrics to target a desired FAR/FRR.

4. **Quality Gates**
   - Adjust `min_focus` and `min_entropy` to reject low‑quality captures.

5. **Snapshots**
   - Save good states with `/registry/snapshot`; restore for demos.

6. **Metrics & Labels**
   - Label `registry/log.csv` in Admin UI; compute EER and push τ.

---

## CI/CD

- **Docker** → GHCR (`edge` on main, `prod` + semver on tags)
- **Android APK** → GitHub Releases on `v*` tags
- **Web** → GitHub Pages + optional Netlify deploy
- Secrets:
  - `ANDROID_KEYSTORE_B64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`
  - `NETLIFY_AUTH_TOKEN`, `NETLIFY_SITE_ID`

---

## License
© GRCode.ai — All rights reserved. For pilots and evaluation only.

---

### GitHub Pages base path
If deploying the web app to GitHub Pages under `https://<org>.github.io/<repo>/`, set:
```bash
# In CI or locally before build
export VITE_BASE='/<repo>/'
npm run build
```
This sets the correct base path for assets and routes.
